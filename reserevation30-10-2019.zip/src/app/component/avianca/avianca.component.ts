import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-avianca',
  templateUrl: './avianca.component.html',
  styleUrls: ['./avianca.component.css']
})
export class AviancaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
