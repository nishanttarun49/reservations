import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-book-seats',
  templateUrl: './how-to-book-seats.component.html',
  styleUrls: ['./how-to-book-seats.component.css']
})
export class HowToBookSeatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
