import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-why-use-us',
  templateUrl: './why-use-us.component.html',
  styleUrls: ['./why-use-us.component.css']
})
export class WhyUseUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
