import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-use-my-account',
  templateUrl: './how-to-use-my-account.component.html',
  styleUrls: ['./how-to-use-my-account.component.css']
})
export class HowToUseMyAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
