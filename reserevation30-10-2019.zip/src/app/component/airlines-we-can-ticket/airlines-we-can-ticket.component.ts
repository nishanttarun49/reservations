import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airlines-we-can-ticket',
  templateUrl: './airlines-we-can-ticket.component.html',
  styleUrls: ['./airlines-we-can-ticket.component.css']
})
export class AirlinesWeCanTicketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
