import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { OwlModule } from 'ngx-owl-carousel';
@Component({
  selector: 'app-travelagent',
  templateUrl: './travelagent.component.html',
  styleUrls: ['./travelagent.component.css']
})
export class TravelagentComponent implements OnInit {
;
  constructor() { }
  mySlideImages:any;
  myCarouselImages:any;
  mySlideOptions:any;
  mySlideOptions2:any;
  myCarouselOptions:any;
  ngOnInit() {
    this.mySlideImages = [1,2,3].map((i)=> `https://picsum.photos/640/480?image=${i}`);
    this.myCarouselImages =[1,2,3,4,5,6].map((i)=>`https://picsum.photos/640/480?image=${i}`);
    this.mySlideOptions={items: 5, dots: false, nav: true,loop:true,autoplay:true};
    this.mySlideOptions2={items: 2, dots: true, nav: true};
    this.myCarouselOptions={items: 3, dots: false, nav:true};
  }

}
