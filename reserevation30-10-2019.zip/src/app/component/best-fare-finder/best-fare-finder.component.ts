import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-best-fare-finder',
  templateUrl: './best-fare-finder.component.html',
  styleUrls: ['./best-fare-finder.component.css']
})
export class BestFareFinderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
