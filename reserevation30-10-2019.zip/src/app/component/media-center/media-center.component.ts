import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-center',
  templateUrl: './media-center.component.html',
  styleUrls: ['./media-center.component.css']
})
export class MediaCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
