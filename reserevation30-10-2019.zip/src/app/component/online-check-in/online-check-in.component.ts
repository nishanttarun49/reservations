import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-check-in',
  templateUrl: './online-check-in.component.html',
  styleUrls: ['./online-check-in.component.css']
})
export class OnlineCheckInComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
