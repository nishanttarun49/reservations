import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alternative-airlines-reviews',
  templateUrl: './alternative-airlines-reviews.component.html',
  styleUrls: ['./alternative-airlines-reviews.component.css']
})
export class AlternativeAirlinesReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
