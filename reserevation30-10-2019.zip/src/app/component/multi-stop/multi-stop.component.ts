import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-stop',
  templateUrl: './multi-stop.component.html',
  styleUrls: ['./multi-stop.component.css']
})
export class MultiStopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
